# Загрузка вакансий в общую БД: общие правила

Для разработчиков парсеров вакансий. Отдельные инструкции по источникам:

- [hh.md](hh.md) — HeadHunter
- [trudvsem.md](trudvsem.md) — «Работа в России»

Обоснование схемы и принятые решения: [../proposals/vacancies.md](../proposals/vacancies.md). Полное DDL: [`db/migrations/0002_vacancies.sql`](../../migrations/0002_vacancies.sql).

## Что уже есть в БД

PostgreSQL 18 (Railway). Таблицы вакансий созданы и пусты; справочник `vacancy_source` заполнен (`hh`, `trudvsem`). В той же БД лежит база предприятий из портала ГУР (`company` и связанные таблицы, ~7,5 тыс. компаний) — с ней вы будете сопоставлять работодателей.

## Подключение

Строку подключения выдаёт владелец БД лично — **не коммитьте её** и не кладите в отчёты. Пример для psycopg 3:

```python
import psycopg

conn = psycopg.connect(host="...", port=..., dbname="railway", user="...", password="...")
```

## Что можно писать

| Таблицы | Кто пишет |
|---|---|
| `vacancy`, `employer_profile`, `vacancy_discovery`, `vacancy_snapshot` | каждый — только строки своего `source` |
| `vacancy_hh` | HH |
| `vacancy_trudvsem`, `region`, `opensanctions_entity`, `opensanctions_code` | trudvsem |
| `classifier_run`, `vacancy_classification`, `employer_classification`, `classification_evidence` | каждый — свои прогоны |
| `employer_company_match`, `vacancy_company_match` | можно добавлять свои кандидатуры (`candidate`, `predicted`); автоматическое сопоставление по ИНН делаем мы после загрузки |
| `manual_review` | ручная проверка |
| `company`, `company_*`, `tool*`, `uav_*`, `weapon`, `component`, `country`, `source_record`, `sanction_jurisdiction`, `vacancy_source` | **только чтение** |

Схему не меняйте сами (никаких `ALTER TABLE`/`CREATE TABLE`). Нужна колонка или таблица — напишите владельцу схемы, изменение придёт новой миграцией в `db/migrations/`.

## Правила для всех

1. **Ключ вакансии — `(source, external_id)`.** Повторная загрузка обновляет строку, а не добавляет дубль. Одна и та же работа на двух сайтах — две разные вакансии; связывать их будем позже отдельно.
2. **Ключ профиля работодателя — `(source, id_namespace, external_id)`.** `id_namespace` — пустая строка `''`, если у источника нет пространств имён.
3. **Даты — `timestamptz` с часовым поясом** (ISO 8601 со смещением). Даты не выдумываем: если источник не даёт значение — `NULL`.
4. **Пустые строки → `NULL`.** Ноль в зарплате и `false` в `salary_gross` — это значения, а не `NULL`.
5. **`first_seen_at` / `last_seen_at`** — когда вакансию впервые и последний раз видел ваш парсер. При обновлении `first_seen_at` не сдвигается назад-вперёд, а берётся минимум; `last_seen_at` — максимум (см. шаблон ниже).
6. **Личные контакты не храним**: ФИО контактных лиц, телефоны, e-mail. Колонок под них нет — не кладите их в другие поля.
7. **Реквизиты работодателя (`inn`, `ogrn`, `kpp`) — как их показывает сайт.** Это утверждение сайта, а не проверенный факт.
8. **Классификация ВПК — только через прогоны.** Одна выгрузка разметки = одна строка `classifier_run`. Старые прогоны не удаляем и не перезаписываем — так сравниваются версии правил.
9. **`level`** — общий словарь: `confirmed`, `likely`, `review`, `no`, `out_of_scope`. Ваша исходная метка — в `raw_label` без изменений, соответствие меток уровням — в `classifier_run.params->'level_map'`.
10. **Сопоставление с `company`:** автоматическое совпадение — статус `auto` (пишем мы), ваши предположения — `candidate` или `predicted` с `method`, `confidence`, `model_version`. Статус `verified` база принимает только с `reviewed_by`, `reviewed_at` и `evidence`.
11. **Сырые данные — файлами.** В `vacancy_snapshot` — путь относительно хранилища источника (`vacancy_source.raw_storage`), позиция внутри файла (`locator`), SHA-256. Где лежит хранилище, сообщите владельцу БД — он запишет его в `vacancy_source.raw_storage`.

## Порядок загрузки

1. `region` (только trudvsem).
2. `employer_profile`.
3. `vacancy` → `vacancy_hh` / `vacancy_trudvsem`.
4. `vacancy_discovery`, `vacancy_snapshot`.
5. `classifier_run` → `vacancy_classification`, `employer_classification`, `classification_evidence`.
6. `opensanctions_*` (trudvsem).
7. После всех загрузок — мы запускаем автоматическое сопоставление `employer_profile` ↔ `company` по ИНН (+КПП).

Грузите пачками в транзакциях (например, по 5–10 тыс. вакансий): при ошибке откатится только пачка, а повтор безопасен благодаря upsert.

## Шаблоны SQL

### Профиль работодателя

```sql
INSERT INTO employer_profile
    (source, id_namespace, external_id, name, url, inn, ogrn, kpp, publisher_type,
     first_seen_at, last_seen_at)
VALUES (%(source)s, %(ns)s, %(ext)s, %(name)s, %(url)s, %(inn)s, %(ogrn)s, %(kpp)s,
        %(ptype)s, %(seen)s, %(seen)s)
ON CONFLICT (source, id_namespace, external_id) DO UPDATE SET
    name           = EXCLUDED.name,
    url            = COALESCE(EXCLUDED.url, employer_profile.url),
    inn            = COALESCE(EXCLUDED.inn, employer_profile.inn),
    ogrn           = COALESCE(EXCLUDED.ogrn, employer_profile.ogrn),
    kpp            = COALESCE(EXCLUDED.kpp, employer_profile.kpp),
    first_seen_at  = LEAST(employer_profile.first_seen_at, EXCLUDED.first_seen_at),
    last_seen_at   = GREATEST(employer_profile.last_seen_at, EXCLUDED.last_seen_at)
RETURNING employer_profile_id;
```

`publisher_type` при обновлении не трогаем: его могли уточнить вручную.

### Вакансия

```sql
INSERT INTO vacancy (source, external_id, url, employer_profile_id, employer_name, title, ...,
                     first_seen_at, last_seen_at, is_active)
VALUES (...)
ON CONFLICT (source, external_id) DO UPDATE SET
    url                 = EXCLUDED.url,
    employer_profile_id = EXCLUDED.employer_profile_id,
    title               = EXCLUDED.title,
    -- ... остальные поля карточки = EXCLUDED.*
    first_seen_at       = LEAST(vacancy.first_seen_at, EXCLUDED.first_seen_at),
    last_seen_at        = GREATEST(vacancy.last_seen_at, EXCLUDED.last_seen_at),
    is_active           = true
RETURNING vacancy_id;
```

Таблица источника (`vacancy_hh` / `vacancy_trudvsem`) — тем же приёмом: `ON CONFLICT (vacancy_id) DO UPDATE`.

### Снять с публикации то, чего нет в свежей полной выгрузке

```sql
UPDATE vacancy SET is_active = false
WHERE source = 'trudvsem' AND last_seen_at < %(snapshot_started_at)s;
```

Только после **полной** выгрузки источника; после частичной — не запускать.

### Прогон классификации

```sql
INSERT INTO classifier_run (classifier, version, rules_sha256, params, started_at, note)
VALUES ('trudvsem_vpk_rules', '2026-10-05', %(sha)s,
        %(params)s::jsonb,   -- {"sanctions_version": "...", "level_map": {"точно": "confirmed", ...}}
        %(started)s, 'первая загрузка')
RETURNING run_id;
```

## Проверка после загрузки

```sql
-- объём и свежесть по источнику
SELECT source, count(*), count(*) FILTER (WHERE is_active) AS active,
       min(first_seen_at), max(last_seen_at)
FROM vacancy GROUP BY source;

-- вакансии без профиля работодателя (у HH ожидается ~40)
SELECT source, count(*) FROM vacancy WHERE employer_profile_id IS NULL GROUP BY source;

-- у каждой вакансии есть строка в таблице своего источника
SELECT v.source, count(*) FROM vacancy v
LEFT JOIN vacancy_hh h USING (vacancy_id) LEFT JOIN vacancy_trudvsem t USING (vacancy_id)
WHERE h.vacancy_id IS NULL AND t.vacancy_id IS NULL GROUP BY v.source;

-- разметка по прогонам
SELECT r.run_id, r.classifier, c.level, count(*)
FROM vacancy_classification c JOIN classifier_run r USING (run_id)
GROUP BY 1, 2, 3 ORDER BY 1, 3;
```

Пришлите владельцу БД результат этих запросов и сколько строк вы ожидали — сверим.
